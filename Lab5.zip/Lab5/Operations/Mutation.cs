﻿using Lab5.Objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Lab5.Operations
{
    public class Mutation
    {
        private Individual _individual;
        Random rand = new Random();
        public Mutation(Individual individual)
        {
            _individual = individual;
        }


    }
}
