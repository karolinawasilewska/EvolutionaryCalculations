﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab6
{
   public class City
    {
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
