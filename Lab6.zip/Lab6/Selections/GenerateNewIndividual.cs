﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab6.Selections
{
    class GenerateNewIndividual
    {
    }
}
